package com.atyeti.healthcare.model;

public enum AppointmentStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}
