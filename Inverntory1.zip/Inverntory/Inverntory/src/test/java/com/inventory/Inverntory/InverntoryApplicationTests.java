package com.inventory.Inverntory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InverntoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
