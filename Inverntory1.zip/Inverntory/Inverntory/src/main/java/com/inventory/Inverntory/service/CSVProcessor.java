package com.inventory.Inverntory.service;


import com.inventory.Inverntory.model.ReportJobStatus;
import com.inventory.Inverntory.repository.ReportJobStatusRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class CSVProcessor {

    @Async
    public void processCSV(MultipartFile file, String jobId, ReportJobStatusRepository jobRepo) {
        try {

            Thread.sleep(5000);


            String outputDir = "reports";
            File dir = new File(outputDir);
            if (!dir.exists()) dir.mkdirs();


            String filename = "report_" + jobId + ".csv";
            Path path = Paths.get(outputDir, filename);
            FileWriter writer = new FileWriter(path.toFile());


            writer.write("ID,Name,Price\n");
            writer.write("1,Item A,100\n");
            writer.write("2,Item B,200\n");
            writer.close();

            ReportJobStatus job = jobRepo.findByJobId(jobId)
                    .orElseThrow(() -> new RuntimeException("Job ID not found: " + jobId));

            job.setStatus("COMPLETED");
            job.setMessage("Report successfully generated.");
            job.setReportPath(path.toAbsolutePath().toString());

            jobRepo.save(job);

        } catch (Exception e) {
            ReportJobStatus job = jobRepo.findByJobId(jobId)
                    .orElseThrow(() -> new RuntimeException("Job ID not found during error: " + jobId));

            job.setStatus("FAILED");
            job.setMessage("Error processing file: " + e.getMessage());
            jobRepo.save(job);
        }
    }
}