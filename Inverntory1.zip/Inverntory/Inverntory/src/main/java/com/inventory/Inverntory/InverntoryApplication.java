package com.inventory.Inverntory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class InverntoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(InverntoryApplication.class, args);
	}

}
