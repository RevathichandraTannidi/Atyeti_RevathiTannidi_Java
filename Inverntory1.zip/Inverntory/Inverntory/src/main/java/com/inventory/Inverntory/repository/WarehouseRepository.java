package com.inventory.Inverntory.repository;

import com.inventory.Inverntory.model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WarehouseRepository extends JpaRepository<Warehouse,String> {
}
