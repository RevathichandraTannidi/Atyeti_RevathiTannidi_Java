package com.inventory.Inverntory.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Warehouse {
    @Id
    private String warehouseId;
    private String name;
}