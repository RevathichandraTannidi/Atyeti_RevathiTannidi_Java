package com.inventory.Inverntory.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportJobStatusDto {
    private String jobId;
    private String status;
    private String message;
}
