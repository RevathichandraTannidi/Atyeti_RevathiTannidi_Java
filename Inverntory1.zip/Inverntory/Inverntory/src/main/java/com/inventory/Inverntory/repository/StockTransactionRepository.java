package com.inventory.Inverntory.repository;

import com.inventory.Inverntory.model.StockTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StockTransactionRepository extends JpaRepository<StockTransaction,Long> {
}
