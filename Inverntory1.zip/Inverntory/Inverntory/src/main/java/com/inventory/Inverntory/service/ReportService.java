package com.inventory.Inverntory.service;


import com.inventory.Inverntory.dto.ReportJobStatusDto;
import com.inventory.Inverntory.model.ReportJobStatus;
import com.inventory.Inverntory.repository.ReportJobStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@Service
public class ReportService {

    @Autowired
    private ReportJobStatusRepository jobRepo;

    @Autowired
    private CSVProcessor csvProcessor;

    public String uploadCSV(MultipartFile file) {
        String jobId = UUID.randomUUID().toString();
        ReportJobStatus job = new ReportJobStatus();
        job.setJobId(jobId);
        job.setStatus("PENDING");
        jobRepo.save(job);

        csvProcessor.processCSV(file, jobId, jobRepo);
        return jobId;
    }

    public ReportJobStatusDto getJobStatus(String jobId) {
        ReportJobStatus job = (ReportJobStatus) jobRepo.findByJobId(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));
        return new ReportJobStatusDto(job.getJobId(), job.getStatus(), job.getMessage());
    }
}