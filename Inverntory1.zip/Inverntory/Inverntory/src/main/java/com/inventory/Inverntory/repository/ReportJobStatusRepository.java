package com.inventory.Inverntory.repository;
import com.inventory.Inverntory.model.ReportJobStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ReportJobStatusRepository extends JpaRepository<ReportJobStatus, Long> {
    Optional<ReportJobStatus> findByJobId(String jobId);
}
