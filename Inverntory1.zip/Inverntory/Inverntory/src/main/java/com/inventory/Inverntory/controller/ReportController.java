package com.inventory.Inverntory.controller;

import com.inventory.Inverntory.dto.ReportJobStatusDto;
import com.inventory.Inverntory.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;

@RestController
@RequestMapping("/api/reports")
@Tag(name = "Report Controller", description = "APIs for uploading CSV and checking report job status")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @Operation(
            summary = "Upload CSV file",
            description = "Uploads an inventory CSV file and initiates a background processing job.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Upload successful, returns job ID"),
                    @ApiResponse(responseCode = "400", description = "Invalid request or file format",
                            content = @Content(mediaType = "application/json"))
            }
    )
    @PostMapping(value = "/upload", consumes = "multipart/form-data")
    public ResponseEntity<String> uploadCSV(
            @Parameter(
                    description = "CSV file to upload",
                    required = true,
                    schema = @Schema(type = "string", format = "binary")
            )
            @RequestParam("file") MultipartFile file
    ) {
        String jobId = reportService.uploadCSV(file);
        return ResponseEntity.ok("Job started: " + jobId);
    }

    @Operation(
            summary = "Get Job Status",
            description = "Returns the status and message for a given job ID",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Job status returned successfully"),
                    @ApiResponse(responseCode = "404", description = "Job not found",
                            content = @Content(mediaType = "application/json"))
            }
    )
    @GetMapping("/status/{jobId}")
    public ResponseEntity<ReportJobStatusDto> getStatus(
            @Parameter(description = "Job ID returned after upload", required = true)
            @PathVariable String jobId
    ) {
        Optional<ReportJobStatusDto> status = Optional.ofNullable(reportService.getJobStatus(jobId));
        return status.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }
}






//package com.inventory.Inverntory.controller;
//
//import com.inventory.Inverntory.dto.ReportJobStatusDto;
//import com.inventory.Inverntory.service.ReportService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//@RestController
//@RequestMapping("/api/reports")
//public class ReportController {
//
//    @Autowired
//    private ReportService reportService;
//
//    @PostMapping("/upload")
//    public ResponseEntity<String> uploadCSV(@RequestParam("file") MultipartFile file) {
//        String jobId = reportService.uploadCSV(file);
//        return ResponseEntity.ok("Job started: " + jobId);
//    }
//
//    @GetMapping("/status/{jobId}")
//    public ResponseEntity<ReportJobStatusDto> getStatus(@PathVariable String jobId) {
//        return ResponseEntity.ok(reportService.getJobStatus(jobId));
//    }
//}